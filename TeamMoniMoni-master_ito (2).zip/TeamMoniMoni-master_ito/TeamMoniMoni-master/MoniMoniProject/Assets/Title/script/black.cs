﻿using UnityEngine;
using System.Collections;

public class black : MonoBehaviour {
   // private bool black_on;
  //  [SerializeField]
  //  private Titleclick title_click = null;
    
	// Use this for initialization
	void Start () {
   //     black_on = false;
          
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
